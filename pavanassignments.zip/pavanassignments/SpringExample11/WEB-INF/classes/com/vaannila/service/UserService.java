package com.vaannila.service;

import com.vaannila.domain.User;

public interface UserService {

	public void add(User user);
}
